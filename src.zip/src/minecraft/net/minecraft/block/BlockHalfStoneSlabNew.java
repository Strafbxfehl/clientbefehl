package net.minecraft.block;

public class BlockHalfStoneSlabNew extends BlockStoneSlabNew
{
    public boolean isDouble()
    {
        return false;
    }
}
