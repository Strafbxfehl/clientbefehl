package clientname.mods.impl;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import clientname.Client;
import clientname.gui.hud.ScreenPosition;
import clientname.mods.ModDraggable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.settings.KeyBinding;

public class ModKeystrokes extends ModDraggable {

	public static enum KeystrokesMode {

		WASD(Key.W, Key.A, Key.S, Key.D), WASD_Mouse(Key.W, Key.A, Key.S, Key.D, Key.LMB, Key.RMB),
		WASD_SPRINT(Key.W, Key.A, Key.S, Key.D,
				new Key("Sprint", Minecraft.getMinecraft().gameSettings.keyBindSprint, 1, 41, 58, 18)),
		// WASD_SPRINT_MOUSE(Key.W, Key.A, Key.S, Key.D, Key.LMB, Key.RMB, new
		// Key("Sprint", Minecraft.getMinecraft().gameSettings.keyBindSprint, 1, 61, 58,
		// 18))
		WASD_SPRINT_MOUSE(Key.W, Key.A, Key.S, Key.D, Key.LMB, Key.RMB, Key.RMBCPS, Key.LMBCPS);
		

		private final Key[] keys;
		private int width = 0;
		private int height = 0;

		private KeystrokesMode(Key... keysIn) {
			this.keys = keysIn;

			for (Key key : keys) {
				this.width = Math.max(this.width, key.getX() + key.getWidth());
				this.height = Math.max(this.height, key.getY() + key.getHeight());
			}
		}

		public int getHeight() {
			return height;
		}

		public int getWidth() {
			return width;
		}

		public Key[] getKeys() {
			return keys;
		}
	}

	private static class Key {

		private static final Key W = new Key("W", Minecraft.getMinecraft().gameSettings.keyBindForward, 21, 1, 18, 18);
		private static final Key A = new Key("A", Minecraft.getMinecraft().gameSettings.keyBindLeft, 1, 21, 18, 18);
		private static final Key S = new Key("S", Minecraft.getMinecraft().gameSettings.keyBindBack, 21, 21, 18, 18);
		private static final Key D = new Key("D", Minecraft.getMinecraft().gameSettings.keyBindRight, 41, 21, 18, 18);

		private static final Key LMB = new Key("LMB", Minecraft.getMinecraft().gameSettings.keyBindAttack, 1, 41, 28,
				18);
		private static final Key RMB = new Key("RMB", Minecraft.getMinecraft().gameSettings.keyBindUseItem, 31, 41, 28,
				18);
		private static final Key LMBCPS = new Key("0", Minecraft.getMinecraft().gameSettings.keyBindAttack, 1, 61,
				28, 18);
		private static final Key RMBCPS = new Key("0", Minecraft.getMinecraft().gameSettings.keyBindUseItem, 31, 61,
				28, 18);

		private final String name;
		private final KeyBinding keyBind;
		private final int x;
		private final int y;
		private final int width;
		private final int height;

		public Key(String name, KeyBinding keyBind, int x, int y, int width, int height) {
			this.name = name;
			this.keyBind = keyBind;
			this.x = x;
			this.y = y;
			this.width = width;
			this.height = height;

		}

		public boolean isDown() {
			return keyBind.isKeyDown();
		}

		public int getHeight() {
			return height;
		}

		public String getName() {
			return name;
		}

		public int getWidth() {
			return width;
		}

		public int getX() {
			return x;
		}

		public int getY() {
			return y;
		}

	}

	private KeystrokesMode mode = KeystrokesMode.WASD_SPRINT_MOUSE;

	public void setMode(KeystrokesMode mode) {
		this.mode = mode;
	}

	@Override
	public int getWidth() {
		return mode.getWidth();
	}

	@Override
	public int getHeight() {
		return mode.getHeight();
	}

	private List<Long> clicksLMB = new ArrayList<Long>();
	private boolean wasPressedLMB;
	private long lastPressedLMB;

	private int getCPSLMB() {
		final long time = System.currentTimeMillis();
		this.clicksLMB.removeIf(aLong -> aLong + 1000 < time);
		return this.clicksLMB.size();
	}
	
	private List<Long> clicksRMB = new ArrayList<Long>();
	private boolean wasPressedRMB;
	private long lastPressedRMB;

	private int getCPSRMB() {
		final long time = System.currentTimeMillis();
		this.clicksRMB.removeIf(aLong -> aLong + 1000 < time);
		return this.clicksRMB.size();
	}
	
	@Override
	public void render(ScreenPosition pos) {

		GL11.glPushMatrix();
		if(Client.ModKeystrokes == true) {
		
		/*
		 * LEFT CLICK
		 */
		
		final boolean pressedLMB = Mouse.isButtonDown(0);
		if (pressedLMB != this.wasPressedLMB) {
			this.lastPressedLMB = System.currentTimeMillis();
			this.wasPressedLMB = pressedLMB;
			if (pressedLMB) {
				this.clicksLMB.add(this.lastPressedLMB);
			}
		}
		Gui.drawRect(pos.getAbsoluteX() + Key.LMBCPS.getX(), pos.getAbsoluteY() + Key.LMBCPS.getY(),
				pos.getAbsoluteX() + Key.LMBCPS.getX() + Key.LMBCPS.getWidth(),
				pos.getAbsoluteY() + Key.LMBCPS.getY() + Key.LMBCPS.getHeight(),
				new Color(0, 0, 0, 142).getRGB());

		font.drawString(getCPSLMB() + "",
				pos.getAbsoluteX() + Key.LMBCPS.getX() + Key.LMBCPS.getWidth() / 2 - font.getStringWidth("000") / 2,
				pos.getAbsoluteY() + Key.LMBCPS.getY() + Key.LMBCPS.getHeight() / 2 - 4,
				-1);
		
		/*
		 * RIGHT CLICK
		 */
		
		final boolean pressedRMB = Mouse.isButtonDown(1);
		if (pressedRMB != this.wasPressedRMB) {
			this.lastPressedRMB = System.currentTimeMillis();
			this.wasPressedRMB = pressedRMB;
			if (pressedRMB) {
				this.clicksRMB.add(this.lastPressedRMB);
			}
		}
		Gui.drawRect(pos.getAbsoluteX() + Key.RMBCPS.getX(), pos.getAbsoluteY() + Key.RMBCPS.getY(),
				pos.getAbsoluteX() + Key.RMBCPS.getX() + Key.RMBCPS.getWidth(),
				pos.getAbsoluteY() + Key.RMBCPS.getY() + Key.RMBCPS.getHeight(),
				new Color(0, 0, 0, 142).getRGB());

		font.drawString(getCPSRMB() + "",
				pos.getAbsoluteX() + Key.RMBCPS.getX() + Key.RMBCPS.getWidth() / 2 - font.getStringWidth("000") / 2,
				pos.getAbsoluteY() + Key.RMBCPS.getY() + Key.RMBCPS.getHeight() / 2 - 4,
				-1);
		
		/*
		 * ALL OTHER KEYS
		 */

		for (Key key : mode.getKeys()) {

			if (key != Key.LMBCPS && key != Key.RMBCPS) {
				int textWidth = font.getStringWidth(key.getName());

				Gui.drawRect(pos.getAbsoluteX() + key.getX(), pos.getAbsoluteY() + key.getY(),
						pos.getAbsoluteX() + key.getX() + key.getWidth(),
						pos.getAbsoluteY() + key.getY() + key.getHeight(),
						key.isDown() ? new Color(255, 255, 255, 102).getRGB() : new Color(0, 0, 0, 102).getRGB());

				font.drawString(key.getName(), pos.getAbsoluteX() + key.getX() + key.getWidth() / 2 - textWidth / 2,
						pos.getAbsoluteY() + key.getY() + key.getHeight() / 2 - 4,
						key.isDown() ? Color.BLACK.getRGB() : Color.WHITE.getRGB());
			}

		}
		}


		GL11.glPopMatrix();

	}

}

