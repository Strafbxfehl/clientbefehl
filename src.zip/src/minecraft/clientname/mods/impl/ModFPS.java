package clientname.mods.impl;

import clientname.Client;
import clientname.gui.UnicodeFontRenderer;
import clientname.gui.hud.ScreenPosition;
import clientname.mods.ModDraggable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;

public class ModFPS extends ModDraggable{
	

	@Override
	public int getWidth() {
		return 50;
	}

	@Override
	public int getHeight() {
		return font.FONT_HEIGHT;
	}

	@Override
	public void render(ScreenPosition pos) {
		if(Client.ModFPS == true) {
		
			font.drawString(Client.KlammerFarbe + "[" + Client.ModFarbe + "FPS" + Client.KlammerFarbe+ "] " + mc.getDebugFPS(), pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
			GlStateManager.pushMatrix();
			Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow(Client.KlammerFarbe + "[" + Client.ModFarbe + "FPS" + Client.KlammerFarbe+ "] " + mc.getDebugFPS(), pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
			GlStateManager.popMatrix();
		

		
		}

}
	
}
