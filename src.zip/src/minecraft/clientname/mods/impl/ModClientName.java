package clientname.mods.impl;

import clientname.Client;
import clientname.gui.hud.ScreenPosition;
import clientname.mods.ModDraggable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;

public class ModClientName extends ModDraggable {


    @Override
    public int getWidth() {
        return font.getStringWidth(Client.ModFarbe + Client.ClientName);
        
    }

    @Override
    public int getHeight() {
        return font.FONT_HEIGHT;
    }

    @Override
    public void render(ScreenPosition pos) {
    	//Gui.drawRect(pos.getAbsoluteX(), pos.getAbsoluteY() , pos.getAbsoluteX() + getWidth() + 1, pos.getAbsoluteY() + getHeight() , 0x90000000);
        font.drawString(Client.ModFarbe + Client.ClientName, pos.getAbsoluteX() + 1, pos.getAbsoluteY() + 1, -1);
        GlStateManager.pushMatrix();
		Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow(Client.ModFarbe + Client.ClientName, pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
		GlStateManager.popMatrix();

    }

    @Override
    public void renderDummy(ScreenPosition pos) {
	//	Gui.drawRect(pos.getAbsoluteX(), pos.getAbsoluteY() , pos.getAbsoluteX() + getWidth() + 1, pos.getAbsoluteY() + getHeight() , 0x90000000);
        font.drawString(Client.ModFarbe + Client.ClientName, pos.getAbsoluteX() + 1, pos.getAbsoluteY() + 1, 0xFF90FF00);
        GlStateManager.pushMatrix();
		Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow(Client.ModFarbe + Client.ClientName, pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
		GlStateManager.popMatrix();
    }


    

}
