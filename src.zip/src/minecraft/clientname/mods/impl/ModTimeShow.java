package clientname.mods.impl;

import java.text.SimpleDateFormat;
import java.util.Date;

import clientname.Client;
import clientname.gui.hud.ScreenPosition;
import clientname.mods.ModDraggable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;

public class ModTimeShow extends ModDraggable{

	@Override
	public int getWidth() {
		return font.getStringWidth("Time: AA:AA:AA AA ");
	}

	@Override
	public int getHeight() {
		return font.FONT_HEIGHT;
	}

	@Override
	public void render(ScreenPosition pos) {
		if(Client.ModTimeShow == true) {
		String pattern = "hh:mm:ss a ";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String time = simpleDateFormat.format(new Date());
		
		
		
		font.drawString(Client.KlammerFarbe + "[" + Client.ModFarbe + "Time" + Client.KlammerFarbe+ "] "+ time, pos.getAbsoluteX() + 1, pos.getAbsoluteY() + 1, -1);
		GlStateManager.pushMatrix();
		Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow(Client.KlammerFarbe + "[" + Client.ModFarbe + "Time" + Client.KlammerFarbe+ "] "+ time, pos.getAbsoluteX() + 1, pos.getAbsoluteY() + 1, -1);
		GlStateManager.popMatrix();
	}
	
	}
}
