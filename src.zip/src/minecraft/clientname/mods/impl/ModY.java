package clientname.mods.impl;
 
import clientname.Client;
import clientname.gui.hud.ScreenPosition;
import clientname.mods.ModDraggable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
 
public class ModY extends ModDraggable {
 
    @Override
    public int getWidth() {
        return 38;
    }
 
    @Override
    public int getHeight() {
        return 10;
 
    }
    
    @Override
    public void render(ScreenPosition pos) {
		if(Client.ModPosition == true) {
        font.drawString(Client.KlammerFarbe + "[" + Client.ModFarbe + "Y" + Client.KlammerFarbe+ "] "+ Math.round((Minecraft.getMinecraft().thePlayer.posY)*1000.0) / 1000, pos.getAbsoluteX() + 2, pos.getAbsoluteY() + 2, -1);
        GlStateManager.pushMatrix();
		Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow(Client.KlammerFarbe + "[" + Client.ModFarbe + "Y" + Client.KlammerFarbe+ "] "+ Math.round((Minecraft.getMinecraft().thePlayer.posY)*1000.0) / 1000, pos.getAbsoluteX() + 2, pos.getAbsoluteY() + 2, -1);
		GlStateManager.popMatrix();
    }
}}