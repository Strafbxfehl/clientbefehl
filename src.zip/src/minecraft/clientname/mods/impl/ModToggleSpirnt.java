package clientname.mods.impl;

import clientname.Client;
import clientname.gui.hud.ScreenPosition;
import clientname.mods.ModDraggable;
import net.minecraft.client.Minecraft;

public class ModToggleSpirnt extends ModDraggable{

	@Override
	public int getWidth() {
		return font.getStringWidth("[Sprinting Toggled]");
	}

	@Override
	public int getHeight() {
		return font.FONT_HEIGHT;
	}

	@Override
	public void render(ScreenPosition pos) {
		if(Client.ToggleSprint == true) {
			mc.fontRendererObj.drawStringWithShadow(Client.KlammerFarbe+"["+ Client.ModFarbe + "Sprinting Toggled"+ Client.KlammerFarbe +"]", pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
		}
		
	}
    public void renderDummy(ScreenPosition pos) {
    	mc.fontRendererObj.drawStringWithShadow(Client.KlammerFarbe+"["+ Client.ModFarbe + "Toggle Sprint"+ Client.KlammerFarbe +"]", pos.getAbsoluteX(), pos.getAbsoluteY(), -1);
    }

}
