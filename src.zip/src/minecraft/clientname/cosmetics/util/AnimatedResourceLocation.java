package clientname.cosmetics.util;



import net.minecraft.util.ResourceLocation;

public class AnimatedResourceLocation {

	private String location;
	protected int frames;
	protected int fpt;
	
	protected int currentTick = 0;
	protected int currentFrame = 0;
	 
	protected ResourceLocation[] textures;
	
	public AnimatedResourceLocation(String location, int frames, int fpt) {
		this.location = location;
		this.frames = frames;
		this.fpt = fpt;
		textures = new ResourceLocation[frames];
		
		for(int i = 0; i< frames; i++) {
				textures[i] = new ResourceLocation(location + "/" + i+ ".png");
		}
		
	}
	
	public void update() {
		if(currentTick > fpt) {
			currentTick = 0;
			currentFrame++;
			if(currentFrame > frames -1) {
				currentFrame = 0;
			}
		}
		currentTick++;
	}
	
	public void setCurrentFrame(int currentFrame) {
		this.currentFrame = currentFrame;
	}
	
	public int getFrames() {
		return frames;
	}
	
	public ResourceLocation getTexture() {
		return textures[currentFrame];
	}
	
	public int getCurrentFrame() {
		return currentFrame;
	}
	
}

