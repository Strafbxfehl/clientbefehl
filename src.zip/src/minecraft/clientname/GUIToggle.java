package clientname;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiShareToLan;
import net.minecraft.client.gui.GuiYesNo;
import net.minecraft.client.gui.achievement.GuiAchievements;
import net.minecraft.client.gui.achievement.GuiStats;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.realms.RealmsBridge;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.IChatComponent;
import net.minecraft.world.WorldSettings;

public class GUIToggle extends GuiScreen  {
	private final GuiScreen field_146598_a;

	private static String Cape = "Cape";
	private static String Wings = "Wings";
	private static String ToggleSprint = "Toggle Sprint";
	private static String Halo = "Halo";
	private static String FPS = "FPS";
	private static String Keystrokes = "Keystrokes";
	private static String Ping = "Ping";
	private static String ArmorStatus = "Armor Status";
	private static String Time = "Time";
	private static String PotionStatus = "Potion Status";
	private static String ModPosition = "ModPosition";
	
//	private static boolean firstStart = false;

	private GuiButton field_146596_f;
	private GuiButton field_146597_g;
	private String field_146599_h = "survival";
	private boolean field_146600_i;

	public GUIToggle(GuiScreen p_i1055_1_) {
		this.field_146598_a = p_i1055_1_;
	}

	/**
	 * Adds the buttons (and other controls) to the screen in question. Called when
	 * the GUI is displayed and when the window resizes, the buttonList is cleared
	 * beforehand.
	 */
	public void initGui() {

		GuiButton guibutton;
		this.buttonList.add(new GuiButton(1003, this.width / 2 - 40, this.height / 2 - 70, 80, 20,I18n.format(Cape, new Object[0])));

		this.buttonList.add(new GuiButton(1001, this.width / 2 - 40, this.height / 2 - 46, 80, 20, I18n.format(Wings, new Object[0])));

		this.buttonList.add(new GuiButton(1002, this.width / 2 + 55, this.height / 2 - 70, 80, 20, I18n.format(ToggleSprint, new Object[0])));
		
		this.buttonList.add(new GuiButton(1012, this.width / 2 + 55, this.height / 2 - 46, 80, 20, I18n.format("ItemPhysics", new Object[0])));
		
		this.buttonList.add(new GuiButton(1013, this.width / 2 + 55, this.height / 2 - 22, 80, 20, I18n.format("1.7 Animations", new Object[0])));

		this.buttonList.add(new GuiButton(1015, this.width / 2 + 50, this.height / 2 + 2, 90, 20, I18n.format("ChatBackground", new Object[0])));

		this.buttonList.add(new GuiButton(1004, this.width / 2 - 40, this.height / 2 - 22, 80, 20, I18n.format(Halo, new Object[0])));
		
		this.buttonList.add(new GuiButton(1014, this.width / 2 - 40, this.height / 2 + 2, 80, 20, I18n.format("DiamondHead", new Object[0])));

		this.buttonList.add(new GuiButton(1005, this.width / 2 - 130, this.height / 2 - 70, 80, 20, I18n.format(FPS, new Object[0])));

		this.buttonList.add(new GuiButton(1006, this.width / 2 - 130, this.height / 2 - 46, 80, 20,  I18n.format(Keystrokes, new Object[0])));

		this.buttonList.add(new GuiButton(1007,this.width / 2 - 130, this.height / 2 - 22, 80, 20, I18n.format(Ping, new Object[0])));

		this.buttonList.add(new GuiButton(1008, this.width / 2 - 130, this.height / 2 + 2, 80, 20, I18n.format(ArmorStatus, new Object[0])));

		this.buttonList.add(new GuiButton(1009, this.width / 2 - 130, this.height / 2 + 26, 80, 20, I18n.format(Time, new Object[0])));
		
		this.buttonList.add(new GuiButton(1010, this.width / 2 - 130, this.height / 2 + 50, 80, 20, I18n.format(PotionStatus, new Object[0])));
		
		this.buttonList.add(new GuiButton(1011, this.width / 2 - 130, this.height / 2 + 74, 80, 20, I18n.format(ModPosition, new Object[0])));
	}


	private void func_146595_g() {
		this.field_146597_g.displayString = I18n.format("selectWorld.gameMode", new Object[0]) + " "
				+ I18n.format("selectWorld.gameMode." + this.field_146599_h, new Object[0]);
		this.field_146596_f.displayString = I18n.format("selectWorld.allowCommands", new Object[0]) + " ";

		if (this.field_146600_i) {
			this.field_146596_f.displayString = this.field_146596_f.displayString
					+ I18n.format("options.on", new Object[0]);
		} else {
			this.field_146596_f.displayString = this.field_146596_f.displayString
					+ I18n.format("options.off", new Object[0]);
		}
	}

	protected void actionPerformed(GuiButton button) throws IOException {
		switch (button.id) {
		case 0:
			this.mc.displayGuiScreen(new GuiOptions(this, this.mc.gameSettings));
			break;

		case 1:
			boolean flag = this.mc.isIntegratedServerRunning();
			boolean flag1 = this.mc.func_181540_al();
			button.enabled = false;
			this.mc.theWorld.sendQuittingDisconnectingPacket();
			this.mc.loadWorld((WorldClient) null);

			if (flag) {
				this.mc.displayGuiScreen(new GuiMainMenu());
			} else if (flag1) {
				RealmsBridge realmsbridge = new RealmsBridge();
				realmsbridge.switchToRealms(new GuiMainMenu());
			} else {
				this.mc.displayGuiScreen(new GuiMultiplayer(new GuiMainMenu()));
			}

		case 2:
		case 3:
		default:
			break;

		case 4:
			this.mc.displayGuiScreen((GuiScreen) null);
			this.mc.setIngameFocus();
			break;

		case 5:
			this.mc.displayGuiScreen(new GuiAchievements(this, this.mc.thePlayer.getStatFileWriter()));
			break;

		case 6:
			this.mc.displayGuiScreen(new GuiStats(this, this.mc.thePlayer.getStatFileWriter()));
			break;
		case 7:
			this.mc.displayGuiScreen(new GuiShareToLan(this));
			break;
		/*case 1002:
			
			
			initAction(ToggleSprint, Client.ToggleSprint, 11, 1101, 10, 70, 50, 20);
			
			
			
			
			break; */
		case 1001:
			Client.CosmeticWings = !Client.CosmeticWings;
			break;
		case 1002:
			Client.ToggleSprint = !Client.ToggleSprint;
			break;
		case 1003:
			Client.CosmeticCape = !Client.CosmeticCape;
			break;
		case 1004:
			Client.CosmeticHalo = !Client.CosmeticHalo;
			break;
		case 8:
			this.mc.displayGuiScreen(new GUIToggle(this));
			break;
		case 1005:
			Client.ModFPS = !Client.ModFPS;
			break;
		case 1006:
			Client.ModKeystrokes = !Client.ModKeystrokes;
			break;
		case 1007:
			Client.ModPing = !Client.ModPing;
			break;
		case 1008:
			Client.ModArmorStatus = !Client.ModArmorStatus;
			break;
		case 1009:
			Client.ModTimeShow = !Client.ModTimeShow;
			break;
		case 1010:
			Client.ModPotionstatus = !Client.ModPotionstatus;
			break;
		case 1011:
			Client.ModPosition = !Client.ModPosition;
			break;
		case 1012:
			Client.ItemPhysics = !Client.ItemPhysics;
			break;
		case 1013:
			Client.BetterAnimations = !Client.BetterAnimations;
			break;
		case 1014:
			Client.DiamondHead = !Client.DiamondHead;
			break;
		case 1015:
			Client.ChatBackground = !Client.ChatBackground;
			break;

		}
	}

	/**
	 * Draws the screen and all the components in it. Args : mouseX, mouseY,
	 * renderPartialTicks
	 */
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		this.drawDefaultBackground();
		this.drawString(fontRendererObj, Client.ModFarbe + Client.ClientName, this.width / 2 - 27, this.height / 2 - 130, -1);
		this.drawString(fontRendererObj, Client.ModFarbe + "Ingame Mods", this.width / 2 - 120, this.height / 2 - 105, -1);
		this.drawString(fontRendererObj, Client.ModFarbe + "Cosmetics", this.width / 2 - 23, this.height / 2 - 105, -1);
		this.drawString(fontRendererObj, Client.ModFarbe + "Other Mods", this.width / 2 + 69, this.height / 2 - 105, -1);
		super.drawScreen(mouseX, mouseY, partialTicks);
	}
	 

}