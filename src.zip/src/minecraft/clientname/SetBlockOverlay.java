package clientname;

	public class SetBlockOverlay {

	    public static float ro = 255.0F;
	    public static float go = 255.0F;
	    public static float bo = 255.0F;
	    public static float ao = 0.4F;
	    public static float THICCNESS = 3.0F;

	    public void setBlockOverlay(float r, float g, float b, float a, float THICCNESSS) { // hehe i get it im immature
	        ro = r;
	        go = g;
	        bo = b;
	        ao = a;
	        THICCNESS = THICCNESSS;
	    }
	}



