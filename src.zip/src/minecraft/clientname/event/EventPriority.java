package clientname.event;

public class EventPriority {
	
	public static final byte FIRST = 0, SECOND = 1, THIRD = 2, FOURTH = 3, FIRTH = 4;
	
	public static final byte[] VALUE_ARRAY = new byte[] {FIRST, SECOND, THIRD, FOURTH, FIRTH};

}
